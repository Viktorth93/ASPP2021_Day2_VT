# Programming Project

For my programming project I intended to improve upon a stacking classifier that combines the output of different machine learning algorithms to make more accurate predictions. My plan is to package the code in a neater, more self-contained way and improve the documentation. I also want to improve the user interface, so that the model can more easily be applied to generic input data.


Link to read the docs documentation page: https://aspp2021-vt.readthedocs.io/en/latest/index.html
